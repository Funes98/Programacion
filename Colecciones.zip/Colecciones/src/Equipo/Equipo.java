package Equipo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import Exception.AlumnoException;



public class Equipo <T> {
	private ArrayList < T > listaEquipo = new ArrayList <T>(); 
	
	private String nombreEquipo; 
	private ArrayList<T> elemento = new ArrayList < T >();
	
	
	
	
	public Equipo() {
		super();
		elemento = new ArrayList < T >();
	}

	public Equipo(String nombre) {
		this();
		this.nombreEquipo=nombreEquipo;
	}
	
	public Equipo(String nombre, ArrayList<T> alumnos) {
		this(nombre);
		this.elemento.addAll(alumnos);
	}


	public void addElemento (T a)throws AlumnoException {
		if (this.elemento.contains(a)) {
			throw new AlumnoException("El alumno ya no esta en el equipo");
			
		}else {
			elemento.add(a);
		}
			
		}
			
		
		
	
	
	
	public void borrarElemento (T a) throws AlumnoException {
		
		if(this.elemento.contains(a)) {
			this.elemento.remove(a);
		}else {
			throw new AlumnoException("El alumno no existe");
		}
		
		
		Iterator<T> it = this.elemento.iterator();
		while(it.hasNext() ) {
			
			if(it.next().equals(a)) {
				it.remove();
			}
		}
	}
	
	public String mostrarAlumnos() {
		StringBuilder sb = new StringBuilder();
		
		Iterator<T> it = this.elemento.iterator();
		while(it.hasNext()) {
			sb.append(it.next()).append(System.lineSeparator());
		}
		
		return sb.toString();}
	
	
	public Alumno contieneAlumno(Alumno a) {
	
		return this.elemento.contains(a)?a:null;	
		}
		
		
		
	
	public Equipo<T> clonarEquipo(){
		Equipo<T> clon = new Equipo<T>("clon");
		for (T t :this.elemento) {
			try {
				clon.addElemento(t);
			}catch(AlumnoException e){
				e.printStackTrace();
			}
			
		}
		
	return clon;}
	
	
	public Equipo<T> interseccionEquipos(Equipo <T> otro) {
		Equipo<T> equipoInter= otro.clonarEquipo();
		equipoInter.elemento.retainAll(this.elemento);
		
	return equipoInter;}
	
	
	public Equipo<T> unionEquipo(Equipo <T> otro) {
		Equipo<T> equipoUnion= new Equipo<>("union", this.elemento);
		
		equipoUnion.elemento;
		
	return equipoUnion;}
	
	

}
