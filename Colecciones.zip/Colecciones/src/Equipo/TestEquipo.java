package Equipo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import Equipo.Alumno;
import Equipo.Equipo;
import org.junit.jupiter.api.Test;

class TestEquipo {
	ArrayList<Alumno> alumnos = new ArrayList<>();
	Alumno al1 = new Alumno("JM", "S", "21212178K");
	Alumno al2 = new Alumno("HF", "S", "23333178K");
	
	Equipo A= new Equipo("betis");
	

	@Test
	void testEquipo() {
		fail("Not yet implemented");
	}

	@Test
	void testEquipoString() {
		fail("Not yet implemented");
	}

	@Test
	void testEquipoStringArrayListOfT() {
		fail("Not yet implemented");
	}

	@Test
	void testAddElemento() {
		fail("Not yet implemented");
	}

	@Test
	void testBorrarElemento() {
		fail("Not yet implemented");
	}

	@Test
	void testMostrarAlumnosOK() {
		alumnos.add(al1);
		Equipo eq = new Equipo("nhtnmjy", alumnos);
		assertEquals("HF S 23333178K", eq.mostrarAlumnos());
	}
	
	@Test
	void testMostrarAlumnosKO() {
		
	}

	@Test
	void testContieneAlumnoOK() {
		alumnos.add(al1);
		Equipo eq = new Equipo("nhtnmjy", alumnos);
		assertEquals(al1, eq.contieneAlumno(al1));
	}
	
	@Test
	void testContieneAlumnoKO() {
		assertEquals(null, A.contieneAlumno(al1));
	}

	@Test
	void testClonarEquipo() {
		fail("Not yet implemented");
	}

	@Test
	void testInterseccionEquipos() {
		fail("Not yet implemented");
	}

}
