package Equipo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import Equipo.Equipo;
import Exception.AlumnoException;
public class Principal {

	public static void main(String[] args) throws AlumnoException {
		//Ejemplo de carga de alumnos repetidos
		        ArrayList<Alumno> alumnos = new ArrayList<>();
				Alumno al1 = new Alumno("JM", "S", "21212178K");
				Alumno al2 = new Alumno("HF", "S", "23333178K");
				alumnos.add(al1);
				alumnos.add(al1);
				
				
				
				
				
				Equipo A = new Equipo("EquipoA", alumnos);
				
				A.mostrarAlumnos();

	}

}
