package Equipo;

import java.util.Objects;

public class Alumno {
	private String nombre;
	private String apellidos;
	private String dni;


public Alumno(String nombre, String apellidos, String dni) {
	super();
	this.nombre = nombre;
	this.apellidos = apellidos;
	this.dni = dni;
}


public String getNombreCompleto() {
	return this.nombre+ " "+this.apellidos;
}




@Override
public int hashCode() {
	return Objects.hash(apellidos, dni, nombre);
}






@Override
public boolean equals(Object alumno) {
	return this==alumno || alumno!=null && alumno instanceof Alumno al && 
			al.hashCode()==this.hashCode();
}





public String toString() {
	return String.format("Alumno con nombre %s %s y dni %s", 
						 this.nombre, this.apellidos, this.dni);
}

}
