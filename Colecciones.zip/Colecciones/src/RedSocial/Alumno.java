package RedSocial;

import java.util.Objects;


import Exception.PersonaException;

public class Alumno extends Persona {

	public Alumno(String nombre, int edad) {
		super(nombre, edad);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void enviarMensaje(String texto, Object destinatario) throws PersonaException {
		if (this.edad<18 && Alumno.equals(destinatario)==true) {
			throw new PersonaException("No es posible enviar el mensaje");
		}else {
			String mensaje=texto;
			
		}

	}

	@Override
	public String leerMensajesBuzon() throws PersonaException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String leerMensajesBuzonOrdenado() throws PersonaException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void borrarMensaje(int codigo) throws PersonaException {
		// TODO Auto-generated method stub

	}

	@Override
	public String buscarFrase(String frase) throws PersonaException {
		
		return null;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(nombre, edad);
	}

	

}
