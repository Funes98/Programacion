package RedSocial;

import java.time.LocalDateTime;
import java.util.Objects;


public class Mensaje {
	private Persona remitente;
	private String texto;
	private LocalDateTime FechaEnvio;
	public Mensaje(Persona remitente, String texto) {
		super();
		this.remitente = remitente;
		this.texto = texto;
		this.FechaEnvio = LocalDateTime.now();
	}
	@Override
	public int hashCode() {
			return Objects.hash(remitente, texto, FechaEnvio);
		}
	
	
	public boolean equals(Object obj) {
		boolean sonIguales = this==obj;
		
		if(!sonIguales && obj!=null && obj instanceof Mensaje) {
			Mensaje ejemplo = (Mensaje)obj;
			
			sonIguales = obj.equals(ejemplo.getFechaEnvio());
			}
	return sonIguales;}
	
	
	public LocalDateTime getFechaEnvio() {
		return FechaEnvio;
	}
	
	
	

}
