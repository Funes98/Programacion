package RedSocial;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import Exception.PersonaException;

public abstract class Persona {
	protected String nombre;
	protected int edad;
	protected List<Mensaje> listaMensajes;
	
	
	
	public Persona(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.listaMensajes=new ArrayList<>();
		
		
	}


	public abstract void enviarMensaje(String texto, Object destinatario)
	throws PersonaException;
	
	public abstract String leerMensajesBuzon()throws PersonaException;
	
	public abstract String leerMensajesBuzonOrdenado()throws PersonaException;
	
	public abstract void borrarMensaje(int codigo)throws PersonaException;
	
	public abstract String buscarFrase(String frase)throws PersonaException;
	
	
	
	
	
	
	
	

}
