package RedSocial;

import Exception.PersonaException;

public abstract class Profesor extends Persona {

	public Profesor(String nombre, int edad) {
		super(nombre, edad);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void enviarMensaje(String texto, Object destinatario) throws PersonaException {
		// TODO Auto-generated method stub

	}

	@Override
	public String leerMensajesBuzon() throws PersonaException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String leerMensajesBuzonOrdenado() throws PersonaException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void borrarMensaje(int codigo) throws PersonaException {
		// TODO Auto-generated method stub

	}

	@Override
	public String buscarFrase(String frase) throws PersonaException {
		// TODO Auto-generated method stub
		return null;
	}

}
