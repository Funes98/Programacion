package RedSocial;

public class Principal {

	public static void main(String[] args) {
		Alumno pepe=new Alumno("pepe", 15);
		Profesor juanito=new Profesor("juanito", 45);
		
		System.out.println(pepe.equals(juanito));
	}

}
