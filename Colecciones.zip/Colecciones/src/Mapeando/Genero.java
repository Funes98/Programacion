package Mapeando;

public enum Genero {
	MASCULINO, FEMENINO, NEUTRO, DESCONOCIDO;

}
