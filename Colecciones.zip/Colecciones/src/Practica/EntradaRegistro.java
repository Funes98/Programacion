package Practica;

public class EntradaRegistro<k, v> {
	
	private k clave;
	private v valor;
	
	
	public EntradaRegistro(k clave, v valor) {
		super();
		this.clave = clave;
		this.valor = valor;
	}


	@Override
	public String toString() {
		return "EntradaRegistro [clave=" + clave + ", valor=" + valor + "]";
	}
	
	
	

}
