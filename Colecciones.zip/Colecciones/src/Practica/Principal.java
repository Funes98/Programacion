package Practica;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Principal {

	public static void main(String[] args) {
		
		String a = new String();

		List<Integer> listaNumeros = new ArrayList<>();
		
		listaNumeros.add(1);
		listaNumeros.add(3);
		listaNumeros.add(3);
		listaNumeros.add(4);
		listaNumeros.add(1);
		listaNumeros.add(4);
		
		
		System.out.println(listaNumeros.get(2));
		Collections.sort(listaNumeros);
		
		
		System.out.println(listaNumeros.size());
		System.out.println(listaNumeros.toString());
		
		
		Set<Integer> conjuntoNumeros = new HashSet<>();
		conjuntoNumeros.addAll(listaNumeros);
		
		System.out.println(listaNumeros.size());
		System.out.println(listaNumeros.toString());
		System.out.println(listaNumeros.isEmpty());

	}

}
