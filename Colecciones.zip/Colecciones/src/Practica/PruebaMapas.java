package Practica;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class PruebaMapas {

	public static void main(String[] args) {

		Map<String, Collection<String>> animalesPorCategoria = new HashMap<>();
		animalesPorCategoria.put("Mamiferos", new HashSet<>());
		animalesPorCategoria.get("Mamiferos").add("Leon");
		animalesPorCategoria.get("Mamiferos").add("TheGoat");
		
		animalesPorCategoria.put("Reptil", new ArrayList<>());
		animalesPorCategoria.get("Reptil").add("Serpiente");
		
		animalesPorCategoria.put("Macaco", new ArrayList<>());
		animalesPorCategoria.get("Macaco").add("Jose Carlos");
		
		System.out.println(animalesPorCategoria.containsKey("Serpiente"));
		System.out.println(animalesPorCategoria.keySet());
		System.out.println(animalesPorCategoria.values());
		System.out.println(animalesPorCategoria.containsKey("Serpiente"));
		System.out.println(animalesPorCategoria.get("Reptil"));


	}

}
