package Exception;

public class PersonaException extends Exception {

	public PersonaException() {
		// TODO Auto-generated constructor stub
	}

	public PersonaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PersonaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PersonaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PersonaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
