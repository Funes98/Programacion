package PruebaMapas;

public enum Genero {
	MASCULINO, FEMENINO, NEUTRO, DESCONOCIDO;

}
