package Diccionario;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DiccionarioTest extends Diccionario {

	@Test
	void testDiccionario() {
		fail("Not yet implemented");
	}

	@Test
	void testAddPalabra() {
		Diccionario esp = new Diccionario();
		assertNull(esp.buscarPalabra("feo"));
		esp.addPalabra("feo", "no es agradable a la vista");
		assertTrue(!esp.buscarPalabra("feo").isEmpty());
		
	}

	@Test
	void testBuscarPalabra() {
		Diccionario esp = new Diccionario();
		esp.addPalabra("suave", "no es duro");
		assertTrue(!esp.buscarPalabra("suave").isEmpty());
		
	}

	@Test
	void testBorrarPalabra() {
		Diccionario esp = new Diccionario();
		esp.addPalabra("guapo", "es agradable a la vista");
		assertTrue(!esp.buscarPalabra("guapo").isEmpty());
		esp.borrarPalabra("guapo");
	    assertTrue(esp.buscarPalabra("guapo").isEmpty());
		assertNull(esp.buscarPalabra("guapo"));
	}
 
	@Test
	void testEliminarSignificado() {
		Diccionario esp = new Diccionario();
		esp.addPalabra("betico", "es del betis");
		assertTrue(!esp.buscarPalabra("guapo").isEmpty());
		esp.eliminarSignificado("betico", "es del betis");
		
		
		
	}

	@Test
	void testListarPalabras() {
		Diccionario esp = new Diccionario();
		esp.addPalabra("betico", "es del betis");
		esp.addPalabra("betico", "es antisevillista");
		assertTrue(!listarPalabras("juan").isEmpty());
		
	}

}
