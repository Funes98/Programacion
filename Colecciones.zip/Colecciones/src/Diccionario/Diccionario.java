package Diccionario;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
public class Diccionario {
	
	
	
	private Map<String, Set<String>> entrada;

	public Diccionario() {
		super();
		this.entrada = new HashMap<>();
	}
	
	
	
	public void addPalabra(String palabra, String significado) {
		
		if(palabra!=null && !palabra.isEmpty() && 
				!entrada.containsKey(palabra)) {
			Set<String> significados = new HashSet<String>();
			significados.add(significado);
			entrada.put(palabra, significados);
			
		}else {
			entrada.get(palabra).add(significado);

		}
		 
	}
	
	public Set<String> buscarPalabra(String palabra) {
		Set<String> resultado = null;
		if (palabra!=null && !palabra.isEmpty()) {
			resultado= entrada.get(palabra);
		}
		
	return resultado;}
	
	public boolean borrarPalabra(String palabra) {
		boolean valida=false;
		if (palabra!=null && !palabra.isEmpty()) {
			entrada.remove(palabra);
			valida=true;
		}
		
	return valida;	
	}
	
	public void eliminarSignificado(String palabra, String significado) {
		entrada.remove(palabra, significado);
	}
	
	public List<String> listarPalabras(String comienza){
		
		List<String> palabras = new ArrayList<String>();
		
		for(String clave : entrada.keySet()) {
			if(clave.startsWith(comienza)) {
				palabras.add(clave);
			}
		} 
		
		Collections.sort(palabras);
		return palabras; 
	}

}
