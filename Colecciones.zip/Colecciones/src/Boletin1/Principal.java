package Boletin1;
import Boletin1.Alumno;
public class Principal {

	public static void main(String[] args) {
		Alumno pepe =new Alumno("jesus","273827382k");
		
		

	}

	

	
	
	
	
		
		
		
	
}
