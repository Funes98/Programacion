package Boletin1;

import java.util.Arrays;

public class UtilidadesArray {
	protected static <T> T[] reverse(T[] arrayOriginal) {
		int length=arrayOriginal.length;
		T[] reverseArray=Arrays.copyOf(arrayOriginal, length);
		
		for (int i=0; i<length/2; i++) {
			T temp=reverseArray[i];
			reverseArray[i]=reverseArray[length -i -1];
			reverseArray[length -i -1]=temp;
		}
		
		
	return reverseArray;}

}
