package PW;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Historial {
	List<PaginaWeb>datos;
	
	
	public Historial () {
		this.datos= new ArrayList<>();
	}
	
	public void addPaginaWeb(PaginaWeb pw)throws Exception {
		if(pw!=null&& datos.isEmpty()|| pw.esPosterior(this.datos.get(this.datos.size()-1))) {
			datos.add(pw);
		}
	}
	
	public String consultarHistorial() throws Exception{
		StringBuilder sb= new StringBuilder();
		
		Iterator it =this.datos.iterator();
		while(it.hasNext()) {
			sb.append(it.next()).append(System.lineSeparator());
		}
		
		return sb.toString();
	}
	
	
	public void borrarHistorial() throws Exception{
		this.datos.clear();
	}
	
	public String mostrarHistorialDia(LocalDate fecha) {
		StringBuilder sb= new StringBuilder();
		
		//for visita
	}

}
