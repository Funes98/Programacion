package PW;

import java.time.LocalDateTime;
import java.util.Objects;





public class PaginaWeb {
	private String url;
	private LocalDateTime FyH;
	
	
	public PaginaWeb(String url) {
		super();
		this.url = url;
		this.FyH=LocalDateTime.now();
	}


	
	public int hashCode() {
		return Objects.hash(url, FyH);
	}


	public boolean equalsPaginaWeb(Object pw) {
		return this==pw || pw!=null && pw instanceof PaginaWeb pw1 && 
				pw1.hashCode()==this.hashCode();
	}



	
	public String toString() {
		return "PaginaWeb [url=" + url + ", FyH=" + FyH + "]";
	}
	
	public boolean esPosterior(PaginaWeb otra) {
		return otra!=null && otra.FyH!=null &&
				this.FyH.isAfter(otra.FyH);
	}



	public String getUrl() {
		return url;
	}



	public void setUrl(String url) {
		this.url = url;
	}



	public LocalDateTime getFyH() {
		return FyH;
	}



	public void setFyH(LocalDateTime fyH) {
		FyH = fyH;
	}
	
	

}

