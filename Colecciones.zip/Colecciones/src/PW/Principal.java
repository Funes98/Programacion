package PW;

import java.util.Scanner;
import PW.Historial;
import PW.PaginaWeb;
public class Principal {

	public static void main(String[] args) throws Exception {
		Scanner sc= new Scanner(System.in);
		int eleccion=0;
		Historial historial=new Historial();
		while(eleccion!=6) {
			System.out.println("1. Nueva página consultada: Se solicitará el nombre de la página y "
					+ "se tomará la fecha\r\n"
					+ "y hora del sistema añadiendo ésta al historial."
					+ " No se permitirá introducir una fecha y\r\n"
					+ "hora anterior a la última almacenada.");
			System.out.println("2. Consultar historial completo");
			System.out.println("3. Consultar historial de un dia");
			System.out.println("4. Borrar todo el historial");
			System.out.println("5. Borrar visitas a una pagina");
			System.out.println("6. Salir");
			eleccion=Integer.valueOf(sc.nextLine());
			
			
			if (eleccion==1) {
				System.out.println("Dime la url: ");
				String url=String.valueOf(sc.nextLine());
				
				PaginaWeb mundo= new PaginaWeb(url);
				
				historial.addPaginaWeb(mundo);
				
			}else if (eleccion==2) {
				historial.consultarHistorial();
			}else if (eleccion==3) {
				
			}else if (eleccion==4) {
				historial.borrarHistorial();
				
			}else if (eleccion==5) {
				
			}
			
			
			
			
			
		}
		
		

	}

	

}
