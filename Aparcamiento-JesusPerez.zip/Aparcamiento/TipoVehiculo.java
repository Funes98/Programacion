package Aparcamiento;

public enum TipoVehiculo {
	AUTOMOVIL,CICLOMOTOR,TRANSPORTE,MERCANCIAS, TRANSPORTE_COLECTIVO

}
