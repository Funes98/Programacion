package Aparcamiento;

public enum Combustible {
	ELECTRICO,GASOLINA,HIBRIDO

}
