package enumerated;

public enum Genero {

	HOMBRE,
	MUJER;
}
