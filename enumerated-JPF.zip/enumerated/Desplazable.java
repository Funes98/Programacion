package enumerated;

public interface Desplazable {
	
	public void moverse();
	public void saltar();
	public void correr();
	public void agacharse();
	
	
	

}
