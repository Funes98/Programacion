package enumerated;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
	
		LocalDate unDia=LocalDate.of(2015,9,15);
		LocalTime hora=LocalTime.of(11,30,14);
		LocalDateTime fechaDef=LocalDateTime.of(unDia,hora);
		String cadena="      La fecha es "+fechaDef+"        ";
		cadena=cadena.trim();
		System.out.println(cadena);
		System.out.println(ChronoUnit.YEARS.between(fechaDef, LocalDateTime.now()));
		Genero generoIntroducido = null;

		do {

		try {

		System.out.println("Introduzca el género: ");

		String generoComoString = new Scanner(System.in).nextLine();

		generoIntroducido = Genero.valueOf(generoComoString.toUpperCase());

		} catch (Exception exception) {

		System.out.println("El valor introducido no es correcto (Hombre/Mujer): ");

		}

		} while (generoIntroducido==null);
		
		
		
		
		
	
Persona jezu=new Persona(generoIntroducido,"jesus","perez",unDia);
Persona mawe=new Persona(generoIntroducido,"mawe","perez",unDia);
Persona clara=new Persona(generoIntroducido,"clara","perez",unDia);
Persona pepe=new Persona(generoIntroducido,"pepe","perez",unDia);
System.out.println(jezu.toString());

jezu.saltar();
jezu.compareTo(generoIntroducido);

Persona[] grupo=new Persona[4];
grupo[0]=jezu;
grupo[0]=mawe;
grupo[0]=clara;
grupo[0]=pepe;

Arrays.sort(grupo);

	}
	
	
	
	public static String arrayToString(Object[] objects) {
		StringBuilder sb = new StringBuilder();
		for(Object o : objects) {
			sb.append(o!=null?o: "").append(System.lineSeparator());
		}
		return sb.toString();
	}

}
