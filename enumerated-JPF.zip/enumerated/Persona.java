package enumerated;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class Persona implements Desplazable  {
	private Genero genero;
	private String nombre;
	private String apellidos;
    private LocalDate fechaNacimiento;
    
    
    
    
	public Persona (Genero genero, String nombre, String apellidos, LocalDate fechaNacimiento) {
		super();
		this.genero = genero;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.fechaNacimiento = fechaNacimiento;
	}




	@Override
	public String toString() {
		return "Persona [genero=" + genero + ", nombre=" + nombre + ", apellidos=" + apellidos + ", fechaNacimiento="
				+ fechaNacimiento + "]";
	}




	@Override
	public void moverse() {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void saltar() {
		
		
	}




	@Override
	public void correr() {
		System.out.println("Ha saltado, no cabe duda");
		
	}




	@Override
	public void agacharse() {
		// TODO Auto-generated method stub
		
	}
    
	
	public int getEdad() {

	return (int) (ChronoUnit.YEARS.between(fechaNacimiento, LocalDateTime.now()));

		}
    
    
    public int compareTo(Genero o) {
    int i =0;	
    if (o==null)	{
    i=-1;	
    }else if(o==this.genero) {
    	i=1;
    }else if (o!=this.genero) {
    	i=0;
    }
    	
    return i;}
    
    
    
    
    
}
