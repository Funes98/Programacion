package SieteYMedia;

import java.util.Comparator;

public class comp implements Comparator<Carta> {

	public int compare(Carta o1, Carta o2) {
		int resultado = 0;
		
		if(o1!=null && o2!=null) {
			resultado = o1.getNumero().compareTo(o2.getNumero());
		}else if(o1==null) {
			resultado = 1;
		}else if(o2==null) {
			resultado = -1;
		}
		
		return resultado;
	}
	

}
