package SieteYMedia;

public enum Palos {
	OROS,COPAS,ESPADAS,BASTOS

}
