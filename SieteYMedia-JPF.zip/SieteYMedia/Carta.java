package SieteYMedia;

public class Carta {
	private Palos palo;
	private int numero;
	
	
	
	
	public Carta(Palos palo, int numero)throws Exception {
		super();
	if(numero<1||numero>12||numero==8||numero==9)	{
		throw new Exception("Valor no valido");
		
		
	}
	this.palo = palo;
	this.numero = numero;
	}

	
	public double getValor() {
	
	return this.numero>9 ? 0.5:this.numero;
	}
	
	
	
	public boolean equals(Object obj) {
		boolean sonIguales = this==obj;
		
		if(!sonIguales && obj!=null && obj instanceof Carta) {
			Carta ejemplo = (Carta)obj;
			
			sonIguales = obj.equals(ejemplo.getNumero());
			
		}
		
		
		return sonIguales;
	}
	
	
	
	
	public Palos getPalo() {
		return palo;
	}


	public int getNumero() {
		return numero;
	}


	public String toString() {
		return String.format("%s de %s", this.numero,this.palo.toString().toLowerCase());
				
	}
	
	
	public int compareTo(Carta o) {
		int resultado=0;
		
	if (this.palo.equals(Palos.OROS)&&this.palo.equals(Palos.COPAS)&&
			this.palo.equals(Palos.BASTOS)
			&&this.palo.equals(Palos.ESPADAS)) {
		resultado=1;
	}else {
		resultado=-1;
	}
		
		
		
	return o.palo.compareTo(this.palo);}
	
	
}
