package SieteYMedia;

import java.util.concurrent.ThreadLocalRandom;

public class Baraja {
	


    private Carta[] cartas;
    private final static int MAX_SIZE=40;
    private int siguiente;

    
	public Baraja() {
		this.cartas=new Carta[MAX_SIZE];
		this.siguiente=0;
		
		int posicion=0;
		
		for(Palos palo: Palos.values()) {//recorremos palos
			for(int i=0; i<13;i++) {  //recorremos valores
				if(i!=8&&i!=9) {
					try {
					this.cartas[posicion++]=new Carta(palo,i); //creamos carta asignando posicion
					}catch (Exception e){
						
					}
					
					
					
				}
			}
			
		}
		
		
		
		
	}
	
	
	public void barajar() {
		int posAnterior=0;
		int posSiguiente=0;
		Carta cartaSig=null;
		Carta cartaAnt=null;
		
		for(int i=0; i<cartas.length;i++) {
		posAnterior= ThreadLocalRandom.current().nextInt(0,MAX_SIZE);
	    cartaAnt=this.cartas[posAnterior];
	    
	    posSiguiente= ThreadLocalRandom.current().nextInt(0,MAX_SIZE);
	    cartaSig=this.cartas[posSiguiente];
	    
	    this.cartas[posAnterior]=cartaSig;
	    this.cartas[posSiguiente]=cartaAnt;
		
		
	}
	}
	
	
	public Carta getSiguiente() {
		
	return this.cartas[siguiente++%MAX_SIZE];
	
	}
	
	
	
	
	private int generaNumero() {
		
	return ThreadLocalRandom.current().nextInt(0,MAX_SIZE);
		
	}
	
	
	
	@Override
	public String toString() {
		return "Baraja [numCartas=" + MAX_SIZE + ", siguiente=" + siguiente + "]";
}






}