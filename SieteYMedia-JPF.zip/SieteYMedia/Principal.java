package SieteYMedia;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);	
		
	Baraja esp= new Baraja();
	esp.barajar();
    Carta [] j1=new Carta[20];
    Carta [] PC=new Carta[20];
    
    int contj1=0;
    int contPC=0;
    
    double  puntosJ1=0;
    double  puntosPC=0;
	
    j1[contj1++]=esp.getSiguiente();
	puntosJ1+=j1[contj1-1].getValor();
    
	boolean jugador=false;
	String elige="SI";
	 do{
		
		
		if(elige.equals("SI")) {
			j1[contj1++] = esp.getSiguiente();
			puntosJ1+=j1[contj1-1].getValor();
			System.out.println("La carta es "+j1[contj1-1]+
					"Puntuacion actual del J1 ="+puntosJ1);
			
		}else {
			jugador=true;
		}
	   contj1++;
		System.out.println("Quieres otra carta? ");
		elige=sc.nextLine().toUpperCase();
		
	}while(jugador==false);
	
	 do{			
			PC[contPC++] = esp.getSiguiente();
			puntosPC+=PC[contPC-1].getValor();
			System.out.println("La carta es "+PC[contPC-1]+
					" Puntuacion actual del PC="+puntosPC);
						
		}while(puntosPC<puntosJ1 && puntosPC<7.5 && puntosJ1<=7.5);
		
	 
	 
	 if(puntosPC>=puntosJ1 && puntosPC<=7.5) {
			System.out.println("PC gana");
		}else {
			if (puntosJ1<=7.5){
				System.out.println("J1 gana");
			}else {
				System.out.println("Resultado nulo");
			}
		}
		
	
		
	
	
	
	

}
}